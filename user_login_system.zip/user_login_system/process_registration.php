<?php
session_start();

$host = "localhost";
$dbname = "user_system";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $year = $_POST['year'];
    $course = $_POST['course'];
    $program = $_POST['program'];

    if (empty($username) || empty($password) || empty($year) || empty($course) || empty($program)) {
        $errorMessage = "All fields are required.";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $errorMessage = "Username already taken. Please choose another one.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (username, password, year, course, program) VALUES (:username, :password, :year, :course, :program)");
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $hashedPassword);
            $stmt->bindParam(':year', $year);
            $stmt->bindParam(':course', $course);
            $stmt->bindParam(':program', $program);
            
            if ($stmt->execute()) {
                $_SESSION['user_id'] = $pdo->lastInsertId(); 
                $_SESSION['username'] = $username; 
 
                header("Location: login.php");
                exit;
            } else {
                $errorMessage = "An error occurred during registration. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Failed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-danger text-center">
            <?php echo isset($errorMessage) ? $errorMessage : "An unexpected error occurred."; ?>
        </div>
        <div class="text-center">
            <a href="register.php" class="btn btn-primary">Go Back to Registration</a>
        </div>
    </div>
</body>
</html>

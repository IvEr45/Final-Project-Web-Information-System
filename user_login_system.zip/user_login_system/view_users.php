<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$host = "localhost";
$dbname = "user_system";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Add new task
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['task_title'])) {
        $task_title = $_POST['task_title'];
        $task_description = $_POST['task_description'];
        
        $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, description, status) 
                               VALUES (:user_id, :title, :description, 'To Do')");
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->bindParam(':title', $task_title, PDO::PARAM_STR);
        $stmt->bindParam(':description', $task_description, PDO::PARAM_STR);
        $stmt->execute();
    }

    // Delete task
    if (isset($_GET['delete_task_id'])) {
        $task_id = $_GET['delete_task_id'];
        
        $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = :task_id AND user_id = :user_id");
        $stmt->bindParam(':task_id', $task_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Move task to In Progress
    if (isset($_GET['move_task_id'])) {
        $task_id = $_GET['move_task_id'];
        
        $stmt = $pdo->prepare("UPDATE tasks SET status = 'In Progress' WHERE id = :task_id AND user_id = :user_id");
        $stmt->bindParam(':task_id', $task_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Move task to Done
    if (isset($_GET['move_to_done_task_id'])) {
        $task_id = $_GET['move_to_done_task_id'];
        
        $stmt = $pdo->prepare("UPDATE tasks SET status = 'Done' WHERE id = :task_id AND user_id = :user_id");
        $stmt->bindParam(':task_id', $task_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Edit task
    if (isset($_POST['edit_task_id'])) {
        // Sanitize and collect the form data
        $task_id = $_POST['edit_task_id'];
        $task_title = $_POST['task_title'];
        $task_description = $_POST['task_description'];
    
        // Check if task exists before proceeding
        $stmt_check = $pdo->prepare("SELECT * FROM tasks WHERE id = :task_id AND user_id = :user_id");
        $stmt_check->bindParam(':task_id', $task_id, PDO::PARAM_INT);
        $stmt_check->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt_check->execute();
    
        if ($stmt_check->rowCount() > 0) {
            // Delete the existing task
            $stmt_delete = $pdo->prepare("DELETE FROM tasks WHERE id = :task_id AND user_id = :user_id");
            $stmt_delete->bindParam(':task_id', $task_id, PDO::PARAM_INT);
            $stmt_delete->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
            $stmt_delete->execute();
    
            // Insert the new task
            $stmt_insert = $pdo->prepare("INSERT INTO tasks (title, description, status, user_id) VALUES (:title, :description, :status, :user_id)");
            $stmt_insert->bindParam(':title', $task_title, PDO::PARAM_STR);
            $stmt_insert->bindParam(':description', $task_description, PDO::PARAM_STR);
            $stmt_insert->bindParam(':status', $status, PDO::PARAM_STR); // You can specify the initial status here
            $stmt_insert->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
            $stmt_insert->execute();
        }
    
        // Redirect to avoid form resubmission and prevent duplication
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Fetch tasks based on status
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = :user_id AND status = 'To Do'");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
    $to_do_tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = :user_id AND status = 'In Progress'");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
    $in_progress_tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = :user_id AND status = 'Done'");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
    $done_tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-image: url(image/pexels-scottwebb-305821.jpg);
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        margin: 0;
        min-height: 100vh;
        color: #2d3748;
    }

    .container {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 2rem;
        min-height: 100vh;
    }

    .welcome-message {
        top: 20px;  /* Keeps the welcome card fixed while scrolling the task cards */
        font-size: 2rem;
        margin: 2rem;
        text-align: center;
        color: black;
    }

    .card-container {
        display: flex;
        gap: 1rem;
        justify-content: center;
        margin-top: 3rem;
    }

    .card {
        width: 250px;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        background-color: #fff;
        text-align: center;
    }

    .card h5 {
        font-size: 1.25rem;
        margin-bottom: 1rem;
    }

    .card p {
        font-size: 1rem;
        color: #777;
    }

    /* Specific styles for the "To Do" and "In Progress" */
    .card-to-do {
        background-color: #ffeb3b;
    }

    .card-in-progress {
        background-color: #64b5f6;
    }

    /* Task action buttons */
    .btn {
        margin-top: 0.5rem;
        font-size: 0.9rem;
        padding: 0.4rem 0.8rem;
        border-radius: 5px;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .btn-warning {
        background-color: #ff9800;
        color: #fff;
    }

    .btn-warning:hover {
        background-color: #f57c00;
        transform: scale(1.05);
    }

    .btn-danger {
        background-color: #e53935;
        color: #fff;
    }

    .btn-danger:hover {
        background-color: #c62828;
        transform: scale(1.05);
    }

    /* Navbar Styling */
    .navbar {
        background: #343a40;
        padding: 1rem 2rem;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
        position: fixed;
        width: 100%;
        top: 0;
        z-index: 1000;
    }

    .navbar a {
        color: #f8f9fa;
        text-decoration: none;
        margin: 0 15px;
        font-weight: 600;
    }

    .navbar a:hover {
        color: #ced4da;
    }

    .navbar-nav {
        flex-direction: row;
        gap: 15px;
    }

    /* Footer Styling */
    .site-footer {
        background: #343a40;
        color: #f8f9fa;
        padding: 3rem 0;
        width: 100%;
        position: relative;
        bottom: 0;
    }

    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 15px;
    }

    .footer-sections {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
    }

    .footer-logo {
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 700;
        font-size: 1.5rem;
    }

    .footer-logo img {
        filter: brightness(0) invert(1);
    }

    .footer-links {
        display: flex;
        gap: 3rem;
    }

    .link-column {
        display: flex;
        flex-direction: column;
    }

    .link-column h5 {
        margin-bottom: 1rem;
        color: #ced4da;
        font-weight: 600;
    }

    .link-column a {
        color: #adb5bd;
        text-decoration: none;
        margin-bottom: 0.5rem;
        transition: color 0.3s ease;
    }

    .link-column a:hover {
        color: #f8f9fa;
    }

    .footer-social {
        display: flex;
        gap: 1rem;
    }

    .social-icon {
        color: #adb5bd;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .social-icon:hover {
        color: #f8f9fa;
    }

    .footer-copyright {
        text-align: center;
        margin-top: 2rem;
        padding-top: 1rem;
        border-top: 1px solid rgba(255,255,255,0.1);
        color: #6c757d;
    }

    /* Additional Responsive Design */
    @media (max-width: 768px) {
        .card-container {
            flex-direction: column;
            gap: 1rem;
        }

        .card {
            width: 100%;
        }
    }
</style>

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="image/kanban-pro-logo.svg" alt="KanbanPro Logo" width="35" height="35" class="d-inline-block align-text-top">
            KanbanPro
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                <li class="nav-item"><a class="nav-link" href="pricing.php">Pricing</a></li>
                <!-- Log Out Button -->
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <button class="btn btn-danger">Log Out</button>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container">
        <div class="welcome-message">
            <h3>Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h3>
        </div>

        <div class="row">
            
            <!-- To Do Card -->
            <div class="col-md-4">
                <div class="card" style="background-color: #ffeb3b;">
                    <h5>To Do</h5>
                    <p>Tasks that are yet to be started</p>
                    <ul class="list-group">
                        <?php foreach ($to_do_tasks as $task): ?>
                            <li class="list-group-item">
                                <strong><?php echo htmlspecialchars($task['title']); ?></strong>
                                <p><?php echo htmlspecialchars($task['description']); ?></p>
                                <a href="?move_task_id=<?php echo $task['id']; ?>" class="btn btn-warning btn-sm">Move to In Progress</a>
                                <a href="?delete_task_id=<?php echo $task['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#editTaskModal"
                            data-task-id="<?php echo $task['id']; ?>"
                            data-task-title="<?php echo $task['title']; ?>"
                            data-task-description="<?php echo $task['description']; ?>">Edit</button>

                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- In Progress Card -->
            <div class="col-md-4">
                <div class="card" style="background-color: #64b5f6;">
                    <h5>In Progress</h5>
                    <p>Tasks that are currently being worked on</p>
                    <ul class="list-group">
                        <?php foreach ($in_progress_tasks as $task): ?>
                            <li class="list-group-item">
                                <strong><?php echo htmlspecialchars($task['title']); ?></strong>
                                <p><?php echo htmlspecialchars($task['description']); ?></p>
                                <a href="?move_to_done_task_id=<?php echo $task['id']; ?>" class="btn btn-success btn-sm">Move to Done</a>
                                <a href="?delete_task_id=<?php echo $task['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editTaskModal" data-task-id="<?php echo $task['id']; ?>" data-task-title="<?php echo $task['title']; ?>" data-task-description="<?php echo $task['description']; ?>">Edit</button>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Done Card -->
            <div class="col-md-4">
                <div class="card" style="background-color: #66bb6a;">
                    <h5>Done</h5>
                    <p>Tasks that are completed</p>
                    <ul class="list-group">
                        <?php foreach ($done_tasks as $task): ?>
                            <li class="list-group-item">
                                <strong><?php echo htmlspecialchars($task['title']); ?></strong>
                                <p><?php echo htmlspecialchars($task['description']); ?></p>
                                <a href="?delete_task_id=<?php echo $task['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editTaskModal" data-task-id="<?php echo $task['id']; ?>" data-task-title="<?php echo $task['title']; ?>" data-task-description="<?php echo $task['description']; ?>">Edit</button>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Add New Task -->
        <div class="card mt-3">
            <div class="card-body">
                <form method="POST">
                    <h5>Add New Task</h5>
                    <input type="text" class="form-control" name="task_title" placeholder="Task Title" required><br>
                    <textarea class="form-control" name="task_description" placeholder="Task Description" required></textarea><br>
                    <button type="submit" class="btn btn-primary">Add Task</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal for Editing Task -->
<!-- Modal for Editing Task -->
<div class="modal fade" id="editTaskModal" tabindex="-1" aria-labelledby="editTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTaskModalLabel">Edit Task</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Hidden input to store task ID -->
                    <input type="hidden" name="edit_task_id" id="edit_task_id">
                    <div class="mb-3">
                        <label for="edit_task_title" class="form-label">Task Title</label>
                        <input type="text" class="form-control" id="edit_task_title" name="task_title" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_task_description" class="form-label">Task Description</label>
                        <textarea class="form-control" id="edit_task_description" name="task_description" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<footer class="site-footer">
        <div class="footer-content">
            <div class="footer-sections">
                <div class="footer-logo">
                    <img src="image/kanban-pro-logo.svg" alt="KanbanPro Logo" width="50" height="50">
                    <span>KanbanPro</span>
                </div>
                <div class="footer-links">
                    <div class="link-column">
                        <h5>Company</h5>
                        <a href="about.php">About Us</a>
                        <a href="careers.php">Careers</a>
                        <a href="contact.php">Contact</a>
                    </div>
                    <div class="link-column">
                        <h5>Product</h5>
                        <a href="features.php">Features</a>
                        <a href="pricing.php">Pricing</a>
                        <a href="integrations.php">Integrations</a>
                    </div>
                    <div class="link-column">
                        <h5>Legal</h5>
                        <a href="privacy.php">Privacy Policy</a>
                        <a href="terms.php">Terms of Service</a>
                    </div>
                </div>
                <div class="footer-social">
                    <a href="#" class="social-icon">Twitter</a>
                    <a href="#" class="social-icon">LinkedIn</a>
                    <a href="#" class="social-icon">GitHub</a>
                </div>
            </div>
            <div class="footer-copyright">
                © 2024 KanbanPro. All Rights Reserved.
            </div>
        </div>
    </footer>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript for modal to edit task
        const editButtons = document.querySelectorAll('.btn-info');
editButtons.forEach(button => {
    button.addEventListener('click', function() {
        const taskId = this.getAttribute('data-task-id');
        const taskTitle = this.getAttribute('data-task-title');
        const taskDescription = this.getAttribute('data-task-description');
        
        // Set the task details in the modal
        document.getElementById('edit_task_id').value = taskId;
        document.getElementById('edit_task_title').value = taskTitle;
        document.getElementById('edit_task_description').value = taskDescription;
    });
});


    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kanban Pro</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            background-image: url(image/back.png);
            background-repeat: no-repeat;
            background-size: 500px 700px;
            background-position: 20% 80%;
            display: flex;
            flex-direction: column;
            justify-content: right;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }

        .content-wrapper {
            flex-grow: 1;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 100%;
            padding-top: 60px;
            padding-right: 10%; 
        }

        .navbar {
            background: #343a40;
            padding: 1rem 2rem;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .navbar a {
            color: #f8f9fa;
            text-decoration: none;
            margin: 0 15px;
            font-weight: 600;
        }

        .navbar a:hover {
            color: #ced4da;
        }

        .navbar-nav {
            flex-direction: row;
            gap: 15px;
        }

        .landing-container {
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            padding: 5.5rem;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px);
            max-width: 600px;
            width: 100%;
            height: 60%;
            margin-bottom: 10rem;
            margin-top: 5rem;
        }

        h1 {
            color: #2c3e50;
            font-weight: 700;
            margin-bottom: 1.5rem;
            font-size: 2.5rem;
            letter-spacing: -0.5px;
        }

        p {
            color: #666;
            font-size: 1rem; /* Slightly reduced from 1.1rem */
            margin-bottom: 2rem;
            line-height: 1.7; /* Increased from 1.6 for better readability */
}

        .btn-custom {
            margin: 8px;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }

        .btn-primary.btn-custom {
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            border: none;
            box-shadow: 0 4px 15px rgba(78, 84, 200, 0.2);
        }

        .btn-success.btn-custom {
            background: linear-gradient(135deg, #11998e, #38ef7d);
            border: none;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.2);
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        .landing-container {
            animation: fadeIn 1s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .site-footer {
            background: #343a40;
            color: #f8f9fa;
            padding: 3rem 0;
            width: 100%;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .footer-sections {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            font-size: 1.5rem;
        }

        .footer-logo img {
            filter: brightness(0) invert(1);
        }

        .footer-links {
            display: flex;
            gap: 3rem;
        }

        .link-column {
            display: flex;
            flex-direction: column;
        }

        .link-column h5 {
            margin-bottom: 1rem;
            color: #ced4da;
            font-weight: 600;
        }

        .link-column a {
            color: #adb5bd;
            text-decoration: none;
            margin-bottom: 0.5rem;
            transition: color 0.3s ease;
        }

        .link-column a:hover {
            color: #f8f9fa;
        }

        .footer-social {
            display: flex;
            gap: 1rem;
        }

        .social-icon {
            color: #adb5bd;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .social-icon:hover {
            color: #f8f9fa;
        }

        .footer-copyright {
            text-align: center;
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(255,255,255,0.1);
            color: #6c757d;
        }

        @media (max-width: 768px) {
            body {
                margin-right: 0;
                justify-content: center;
            }

            .content-wrapper {
                padding-top: 0;
            }

            .landing-container {
                margin: 20px;
            }

            .footer-sections {
                flex-direction: column;
                text-align: center;
            }
    
            .footer-links {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="image/kanban-pro-logo.svg" alt="KanbanPro Logo" width="35" height="35" class="d-inline-block align-text-top">
            KanbanPro
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pricing.php">Pricing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="register.php">Register</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="content-wrapper">
    <!-- Landing Page Content -->
    <div class="landing-container">
        <h1 class="animate__animated animate__fadeInDown">Welcome</h1>
        <p class="animate__animated animate__fadeIn animate__delay-1s">Welcome to KanbanPro – Your ultimate tool for organizing tasks and boosting productivity. Whether you're working on personal projects or collaborating with a team, our intuitive Kanban board system will help you stay on top of your goals, prioritize effectively, and get things done. Join us today and experience a smarter way to manage your tasks!</p>
        <div class="animate__animated animate__fadeInUp animate__delay-1s">
            <a href="login.php" class="btn btn-primary btn-custom">Login</a>
            <a href="register.php" class="btn btn-success btn-custom">Register</a>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="site-footer">
    <div class="footer-content">
        <div class="footer-sections">
            <div class="footer-logo">
                <img src="image/kanban-pro-logo.svg" alt="KanbanPro Logo" width="50" height="50">
                <span>KanbanPro</span>
            </div>
            <div class="footer-links">
                <div class="link-column">
                    <h5>Company</h5>
                    <a href="about.php">About Us</a>
                    <a href="careers.php">Careers</a>
                    <a href="contact.php">Contact</a>
                </div>
                <div class="link-column">
                    <h5>Product</h5>
                    <a href="features.php">Features</a>
                    <a href="pricing.php">Pricing</a>
                    <a href="integrations.php">Integrations</a>
                </div>
                <div class="link-column">
                    <h5>Legal</h5>
                    <a href="privacy.php">Privacy Policy</a>
                    <a href="terms.php">Terms of Service</a>
                </div>
            </div>
            <div class="footer-social">
                <a href="#" class="social-icon">Twitter</a>
                <a href="#" class="social-icon">LinkedIn</a>
                <a href="#" class="social-icon">GitHub</a>
            </div>
        </div>
        <div class="footer-copyright">
            © 2024 KanbanPro. All Rights Reserved.
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>